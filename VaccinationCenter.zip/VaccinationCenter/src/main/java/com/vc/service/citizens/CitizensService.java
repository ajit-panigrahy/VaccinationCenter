package com.vc.service.citizens;

import java.util.List;

import com.vc.entities.Cities;
import com.vc.entities.Citizens;

public interface CitizensService {

	public List<Citizens> findAll();
	public Citizens getCitizen(int citizenid);
	public void removeCitizen(int citizenid);
	public void addCitizen(Citizens citizen);
	public List<Cities> cityList();
	public void updateCitizen(Citizens citizen);

}
