package com.vc.service.citizens;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vc.entities.Cities;
import com.vc.entities.Citizens;
import com.vc.repository.CitizenRepository;
import com.vc.repository.CityRepository;

@Service
public class GetCitizenService implements CitizensService {

	@Autowired
	CitizenRepository citizenRepository;
	@Autowired
	CityRepository cityRepository;

	@Override
	public List<Citizens> findAll() {
		return citizenRepository.findAll();
	}

	@Override
	public Citizens getCitizen(int citizenid) {
		return citizenRepository.findById(citizenid).orElse(null);
	}

	@Override
	public void removeCitizen(int citizenid) {
		citizenRepository.deleteById(citizenid);
	}

	@Override
	public void addCitizen(Citizens citizen) {
		citizenRepository.save(citizen);
	}

	@Override
	public List<Cities> cityList() {
		List<Cities> cities = cityRepository.findAll();
		return cities;
	}

	@Override
	public void updateCitizen(Citizens citizen) {
		citizenRepository.saveAndFlush(citizen);
	}

}
