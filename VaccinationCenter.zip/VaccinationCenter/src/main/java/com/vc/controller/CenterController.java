package com.vc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vc.entities.Centers;
import com.vc.service.center.CenterServices;

@Controller
public class CenterController {

	@Autowired
	CenterServices centerServices;

	@GetMapping("/centerlist")
	public String centerList(Model m) {

		List<Centers> centers = centerServices.allCenters();
		m.addAttribute("centerlist", centers);
		return "vaccinationcenters";
	}

	@GetMapping("/addcenter")
	public String addcenter(Model model) {
		model.addAttribute("cityList", centerServices.cityList());
		return "addcenter";
	}

	@PostMapping("/addnewcenter")
	public String addnewcenter(@ModelAttribute Centers centers) {
		centerServices.addCenter(centers);
		return "redirect:/centerlist";
	}

	@GetMapping("/deletecenter")
	public String deleteCenter(@RequestParam("cid") int centerid) {
		centerServices.removeCenter(centerid);
		return "redirect:/centerlist";
	}

	@GetMapping("/updatecenter")
	public String updateCenter(@RequestParam("cid") int centerid, Model model) {
		Centers center = centerServices.getCenter(centerid);
		model.addAttribute("center", center);
		model.addAttribute("cityList", centerServices.cityList());
		return "editcenter";
	}

	@PostMapping("/updatethecenter")
	public String updateTheCenter(@ModelAttribute Centers center) {
		centerServices.updateCenter(center);
		return "redirect:/centerlist";
	}

	@GetMapping("/viewcenter")
	public String viewCenter(@RequestParam("cid") int centerid, Model model) {
		Centers center = centerServices.getCenter(centerid);
		model.addAttribute("center", center);
		model.addAttribute("citizenlist", center.getCitizens());
		return "viewcenter";
	}
}
