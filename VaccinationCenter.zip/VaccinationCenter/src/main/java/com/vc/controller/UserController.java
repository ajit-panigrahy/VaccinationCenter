package com.vc.controller;

import org.springframework.ui.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.vc.entities.User;
import com.vc.service.user.UserService;

@Controller
public class UserController {

	@Autowired
	UserService service;

	@GetMapping("/")
	public String loginPage() {
		return "login";
	}
	@GetMapping("/registration")
	public String showRegistrationPage() {
		return "registration";
	}

	@PostMapping("/registeruser")
	public String registerUser(@ModelAttribute("user") User user) {
		service.addUser(user);
		return "login";
	}

	@PostMapping("/login")
	public String validateLogin(@RequestParam("email") String email,
			@RequestParam("password") String password, Model model) {

		User user = service.getUser(email, password);
		if (user != null) {
			model.addAttribute("user", user.getName());
			return "redirect:/centerlist";
		}
		model.addAttribute("errorMessage",
				"Invalid credentials. Please try again.");

		return "login";
	}

}
