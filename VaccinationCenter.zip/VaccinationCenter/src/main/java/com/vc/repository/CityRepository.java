package com.vc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.vc.entities.Cities;

public interface CityRepository extends JpaRepository<Cities, Integer> {

}
