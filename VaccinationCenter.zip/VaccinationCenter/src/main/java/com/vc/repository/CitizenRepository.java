package com.vc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.vc.entities.Centers;
import com.vc.entities.Citizens;

@Repository
public interface CitizenRepository extends JpaRepository<Citizens, Integer> {

	List<Citizens> findByCenterid(Centers center);

	List<Citizens> findByCenteridAndDose(Centers center, int dose);

}
